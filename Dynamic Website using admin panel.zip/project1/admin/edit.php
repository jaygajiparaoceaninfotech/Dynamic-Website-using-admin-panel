<?php
// Include database connection
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $slider_heading = htmlspecialchars($_POST['slider_heading']);
    $title = htmlspecialchars($_POST['title']);
    $description = htmlspecialchars($_POST['description']);
    
    // Handle file upload (optional, if you want to allow changing the image)
    $image = $_FILES['image']['name'];
    $target = "uploads/" . basename($image);
    
    // Check if a new image was uploaded
    if (!empty($image)) {
        // Move the uploaded file to the target directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            // Update query with new image
            $stmt = $conn->prepare("UPDATE slider SET slider_heading=?, title=?, description=?, image=?, modified_date=CURRENT_TIMESTAMP WHERE id=?");
            $stmt->bind_param("ssssi", $slider_heading, $title, $description, $target, $id);
        } else {
            echo "Failed to upload image: " . error_get_last()['message']; // Debugging output
            exit();
        }
    } else {
        // Update query without changing the image
        $stmt = $conn->prepare("UPDATE slider SET slider_heading=?, title=?, description=?, modified_date=CURRENT_TIMESTAMP WHERE id=?");
        $stmt->bind_param("sssi", $slider_heading, $title, $description, $id);
    }

    // Execute and check for success
    if ($stmt->execute()) {
        echo "Record updated successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    // Redirect to the table page
    header('Location: table.php');
    exit();
}

// Fetch the record to edit
$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM slider WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <h1 class="text-center">Edit Record</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <div class="form-group">
                <label for="slider_heading">Sider Heading:</label>
                <input type="text" class="form-control" name="slider_heading" value="<?php echo $row['slider_heading']; ?>" required>
            </div>

            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" name="title" value="<?php echo $row['title']; ?>" required>
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <textarea class="form-control" name="description" required><?php echo $row['description']; ?></textarea>
            </div>

            <div class="form-group">
                <label for="image">Image:</label>
                <input type="file" class="form-control-file" name="image" accept="image/*">
                <img src="<?php echo $row['image']; ?>" alt="Current Image" style="width: 100px; margin-top: 10px;">
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
        <a href="table.php" class="btn btn-secondary">Cancel</a>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close statement and connection
$stmt->close();
$conn->close();
?>
