<footer class="footer">
        <div class="container-fluid d-flex justify-content-between">
          <nav class="pull-left">
            <ul class="nav">
              <li class="nav-item">
                <a class="nav-link" href="https://www.oceaninfotech.co.in/">
                Ocean Infotech
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"> Help </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"> Licenses </a>
              </li>
            </ul>
          </nav>
          <div class="copyright">
            2024, made with <i class="fa fa-heart heart text-danger"></i> by
            <a href="https://www.oceaninfotech.co.in/">Ocean Infotech</a>
          </div>
          <div>
            Distributed by
            <a target="_blank" href="https://www.oceaninfotech.co.in/">Ocean Infotech</a>.
          </div>
        </div>
      </footer>