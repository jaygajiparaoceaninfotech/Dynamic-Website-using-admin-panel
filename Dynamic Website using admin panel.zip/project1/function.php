<!-- about  -->
<?php
    // Database connection
    // Database connection

    include 'connection.php';

    // SQL query to fetch all slider details
    $sql = "SELECT * FROM about"; // Corrected the column name
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        // Fetch the data
        while ($row = $result->fetch_assoc()) {
            $about_heading= $row['about_heading']; // Make sure this variable is defined
            $about_title = $row['about_title'];
            $about_description = $row['about_description'];
            $image = $row['image'];
        }
    } 

?>
<!-- service  -->
<?php
include("connection.php");
// Fetch services from the database
$sql = "SELECT * FROM services";
$result = $conn->query($sql);
?>



<?php $conn->close(); ?>

