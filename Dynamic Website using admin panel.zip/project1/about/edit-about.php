<?php
include 'connection.php';

session_start(); // Start the session to access session variables

// Check if the user is logged in, otherwise redirect to login page
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Check if 'id' is set in the URL or request
if (!isset($_GET['id'])) {
    echo "Invalid request.";
    exit();
}

$id = intval($_GET['id']); // Get the ID safely
$result = $conn->query("SELECT * FROM about WHERE id = $id");
$row = $result->fetch_assoc(); // Fetch the record to edit

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Use new variable names
    $about_heading = htmlspecialchars($_POST['about_heading']);
    $about_title = htmlspecialchars($_POST['about_title']);
    $description = htmlspecialchars($_POST['description']); // Store HTML description directly

    // Handle file upload
    $new_image = $_FILES['image']['name'];
    $target = "uploads/" . basename($new_image);

    // Prepare the statement
    if (!empty($new_image)) {
        // Check for file upload errors
        if ($_FILES['image']['error'] === UPLOAD_ERR_OK) {
            // Delete the old image before uploading the new one
            if (file_exists($row['image'])) {
                unlink($row['image']); // Deletes the old image
            }

            // Move the uploaded file to the target directory
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                // Update query with new image
                $stmt = $conn->prepare("UPDATE about SET about_heading=?, about_title=?, description=?, image=?, modified_date=CURRENT_TIMESTAMP WHERE id=?");
                $stmt->bind_param("ssssi", $about_heading, $about_title, $description, $target, $id);
            } else {
                echo "Failed to upload image.";
                exit();
            }
        } else {
            echo "Error uploading image: " . $_FILES['image']['error'];
            exit();
        }
    } else {
        // Update query without changing the image
        $stmt = $conn->prepare("UPDATE about SET about_heading=?, about_title=?, description=?, modified_date=CURRENT_TIMESTAMP WHERE id=?");
        $stmt->bind_param("sssi", $about_heading, $about_title, $description, $id);
    }

    // Execute and check for success
    if ($stmt->execute()) {
        echo "Record updated successfully.";
        // Redirect to the table page
        header('Location: about-us.php');
        exit();
    } else {
        error_log("Error updating record: " . $stmt->error); // Log the error for debugging
        echo "An error occurred. Please try again.";
    }

    // Close statement and connection
    $stmt->close();
}

$username = htmlspecialchars($_SESSION['username']);

// Ensure row data is present
if (!$row) {
    echo "Record not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Kaiadmin - Bootstrap 5 Admin Dashboard</title>
    <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
    <link rel="icon" href="assets/img/kaiadmin/favicon.ico" type="image/x-icon" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-KyZXEAg3QhqLMpG8r+Knujsl5+5hb7B4b8FszMCQeKN3tmGb9/ywYXb2cl1M2trb" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ZENpIfx3ZFl2BOk+R4DsGGS1LfaSpCnq8Pcp1O89NfwT1p8l+AL2D7dD5qn7cOJC" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.ckeditor.com/4.20.0/standard/ckeditor.js"></script>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/plugins.min.css" />
    <link rel="stylesheet" href="assets/css/kaiadmin.min.css" />
    <link rel="stylesheet" href="assets/css/demo.css" />
</head>

<body>
    <div class="wrapper">
        <div class="sidebar" data-background-color="dark">
            <div class="sidebar-logo">
                <?php include 'header.php'; ?>
            </div>
            <div class="sidebar-wrapper scrollbar scrollbar-inner">
                <div class="sidebar-content">
                    <ul class="nav nav-secondary">
                        <li class="nav-item">
                            <a href="index.php">
                                <i class="fas fa-home"></i>
                                <p>Dashboard</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="forms.php">
                                <i class="fas fa-pen-square"></i>
                                <p>Forms</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="datatables.php">
                                <i class="fas fa-table"></i>
                                <p>Tables</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="slider.php">
                                <i class="fa-solid fa-sliders"></i>
                                <p>Slider</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="services.php">
                                <i class="fa-solid fa-briefcase"></i>
                                <p>Services</p>
                            </a>
                        </li>
                        <li class="nav-item active">
                            <a href="about-us.php">
                                <i class="fas fa-info"></i>
                                <p>About us</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="main-panel">
            <div class="main-header">
                <?php include 'navbar.php'; ?>
            </div>
            <div class="container">
                <div class="page-inner">
                    <div class="page-header">
                        <h3 class="fw-bold mb-3">Manage About Page</h3>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="container d-flex align-items-center justify-content-center min-vh-100">
                                <div class="card w-100" style="max-width: 600px;">
                                    <div class="card-body">
                                        <h3 class="text-center mb-4">Edit About Record</h3>
                                        <form action="" method="post" enctype="multipart/form-data">
                                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                            
                                            <div class="mb-3">
                                                <label for="about_heading" class="form-label">About Heading</label>
                                                <input type="text" class="form-control" id="about_heading" name="about_heading" value="<?php echo $row['about_heading']; ?>" required>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="about_title" class="form-label">About Title</label>
                                                <input type="text" class="form-control" id="about_title" name="about_title" value="<?php echo $row['about_title']; ?>" required>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="description" class="form-label">Description</label>
                                                <textarea class="form-control" id="description" name="description" rows="3" required><?php echo $row['description']; ?></textarea>
                                            </div>

                                            <div class="mb-3">
                                                <label for="image" class="form-label">Upload Image</label>
                                                <input type="file" class="form-control" id="image" name="image" accept="image/*">
                                                <div class="mt-3">
                                                    <img src="<?php echo $row['image']; ?>" alt="Current Image" style="width: 100px;">
                                                </div>
                                            </div>
                                            
                                            <div class="d-flex justify-content-between">
                                                <button type="submit" class="btn btn-primary">Update</button>
                                                <a href="about-us.php" class="btn btn-secondary">Cancel</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include 'footer.php'; ?>

        </div>
    </div>

    <!-- Initialize CKEditor -->
    <script>
        CKEDITOR.replace('description', {
            allowedContent: {
                $1: {
                    elements: CKEDITOR.dtd,
                    attributes: true,
                    styles: true
                }
            }
        });
    </script>

    <script src="assets/js/core/jquery-3.7.1.min.js"></script>
    <script src="assets/js/core/popper.min.js"></script>
    <script src="assets/js/core/bootstrap.min.js"></script>
    <script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
    <script src="assets/js/plugin/chart.js/chart.min.js"></script>
    <script src="assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>
    <script src="assets/js/plugin/chart-circle/circles.min.js"></script>
    <script src="assets/js/plugin/datatables/datatables.min.js"></script>
    <script src="assets/js/plugin/jsvectormap/jsvectormap.min.js"></script>
    <script src="assets/js/plugin/jsvectormap/world.js"></script>
    <script src="assets/js/plugin/sweetalert/sweetalert.min.js"></script>
    <script src="assets/js/kaiadmin.min.js"></script>
    <script src="assets/js/setting-demo.js"></script>
    <script src="assets/js/demo.js"></script>
</body>
</html>
